/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
import java.util.Random;
/**
 *
 * @author awils_000
 */
public class FirstgradeMath {
    public static void main(String[] args){
        
    
   Random rand = new Random();
   Scanner sc = new Scanner(System.in);
   
    int randomOne = 0, random2 =0, problems =1;
   int sum =0, userAnswer = 0, correct = 0, incorrect =0;
   
   
   
 while(problems <= 10){
    System.out.printf("\nProblem %d: \n", problems);
    randomOne = rand.nextInt(11);
    random2 = rand.nextInt(11);
    sum = randomOne + random2;
    System.out.println(randomOne + "+" + random2+"\n");
    userAnswer = sc.nextInt();
    if(userAnswer == sum){
        System.out.printf("CORRECT");
        correct++;}
        else{
                System.out.printf("INCORRECT");
                incorrect++;
                }
    
   problems ++; 
 }
    System.out.printf("You Got " + correct + "Correct" );
        System.out.printf("You Got " + incorrect + "Correct" );

    }    
}
